const FooterSosmed = () => {
    return (
      <div className="w-full h-45 pl-14 bg-green-300 md:pl-16">
        <p className="text-slate-600 sm:text-sm md:text-base">@2023 Gerobak Sayur All Rights Reserved</p>
      </div>
    );
}

export default FooterSosmed;