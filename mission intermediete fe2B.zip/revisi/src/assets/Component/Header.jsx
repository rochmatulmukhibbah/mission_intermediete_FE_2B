const Header = () => {
    return (
            <div className="flex justify-between w-full h-45px bg-green-200">
           <span><img src="Type=Type5.png"/>
           </span>
           <div className=" flex items-center ">
            <a href="#" class="text-xl text-black hover:text-rose-500 duration-400">Kategori</a>
            <img className="md:flex md:items-center size-10 mx-5 object-cover " src="ava14.jfif"/>
           </div>  
           </div>
    );
}

export default Header;