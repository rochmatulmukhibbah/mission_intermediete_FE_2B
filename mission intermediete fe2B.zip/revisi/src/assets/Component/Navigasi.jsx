const Subtitle = () => {
    return (
        <div className="h-11 flex bg-green-200 pl-28 w-full sm:pl-14 sm:items-center md:pl-16">
           <a href="#" class="text-xl text-black hover:text-rose-500 duration-400 sm:text-base">Semua Kelas</a>
           <a href="#" class="text-xl text-black pl-7 hover:text-rose-500 duration-400 sm:text-base">Pemasaran</a>
           <a href="#" class="text-xl text-black pl-7 hover:text-rose-500 duration-400 sm:text-base">Desain</a>
           <a href="#" class="text-xl text-black pl-7 hover:text-rose-500 duration-400 sm:text-base">Pengembangan Diri</a>
           <a href="#" class="text-xl text-black pl-7 hover:text-rose-500 duration-400 sm:text-base">Bisnis</a>
        </div>
    );
}

export default Subtitle;